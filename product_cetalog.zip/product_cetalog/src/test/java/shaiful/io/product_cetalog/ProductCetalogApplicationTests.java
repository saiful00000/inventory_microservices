package shaiful.io.product_cetalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductCetalogApplicationTests {

	@Test
	void contextLoads() {
	}

}
